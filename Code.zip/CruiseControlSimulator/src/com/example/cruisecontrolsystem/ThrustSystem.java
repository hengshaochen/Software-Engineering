package com.example.cruisecontrolsystem;

class ThrustSystem extends CruiseControlSystem
{

	public int addSpeed( int speed, int changePercentage )
	{
		int k = 1;
		
		speed = speed + ( k*changePercentage );
		return speed;
		//setSpeed( newSpeed );
	}
	
	public int addSpeedConstant( int speed, int speedConstant )
	{
		speed = speed + speedConstant;
		return speed;
	}

	public void calculateKconst()
	{
		
	}
}
