package com.example.cruisecontrolsystem;

import java.util.Random;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Message;
import android.util.DisplayMetrics;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

public class play extends Activity
{
	// 介面相關參數
	Bitmap bmp, carBmp, leadCarBmp, barrier;
	private float x=0,y=0;
    int left = -50;
    int top = 0;
    int counter = 0;
    
	//int[] barrierPosition = new int[1000];
	//int[] barrier_left_right = new int[1000];
	
	int[] car2Position = new int[50];
	int[] car2LeftRight = new int[50];
	
	// 選一種mode來使用 隨機速度
	int[] car2Speed = new int[50];
	int car2_speed = 10;
	// 選一種mode來使用
	
	int leadCarPosition = 400;
	int leadCarPosition_left_right = 340;
	
	
	Handler handler;
	CharSequence mText;
	String mString;
    private  static  final  int msgKey1 =  1 ; 
    private TextView mTime; 
	TextView safeOrNotText;
	TextView speedText;
	boolean gameState = true;
	
    int recordCarNumber = -1;
    
    // 系統物件相關參數
	CruiseControlSystem CruiseControlSystem = new CruiseControlSystem();
	SensorSystem SensorSystem = new SensorSystem();
	
    /** Called when the activity is first created. */
   @Override
	public  void onCreate(Bundle savedInstanceState) 
	{
	   	super .onCreate(savedInstanceState);
	   	requestWindowFeature(Window.FEATURE_NO_TITLE); 
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
		WindowManager.LayoutParams.FLAG_FULLSCREEN);
	    setContentView(R.layout.play);
        //mTime = (TextView) findViewById(R.id.distanceText); 
        
        
        // 製造1000個亂數
    	Random random = new Random();
    	for( int i=0 ; i<50 ; i++ )
    	{
    		car2Position[i] = random.nextInt(30000) - 30000;
    		car2LeftRight[i] = random.nextInt(500);
    		car2Speed[i] = random.nextInt(30);
    	}
        
        new TimeThread().start();
	    
	   
	    // 介面
	    LinearLayout playView = (LinearLayout)findViewById(R.id.root);
	    Panel p = new Panel(this);
	    playView.addView(p);
	       
	    // 系統物件 參數

		final ThrustSystem t1 = new ThrustSystem();
		final SpeedBreakSystem speedbreak = new SpeedBreakSystem();
		//final TextView speedText=(TextView)findViewById(R.id.speedText);
		final TextView informationText=(TextView)findViewById(R.id.informationText);
		final TextView distanceText=(TextView)findViewById(R.id.distanceText);
		speedText=(TextView)findViewById(R.id.speedText);
		speedText.setTextColor(Color.BLUE);
		CruiseControlSystem.setSpeed(0);
		speedText.setText("*速度:"+ CruiseControlSystem.getSpeed() +"km/hr");
		
			
		// 按鈕 ---> 加速(按一次加10)
	    Button thrust = (Button)findViewById(R.id.thrustButton); 
	    thrust.setOnClickListener(new Button.OnClickListener()
	    {
	    	@Override
	    	public void onClick(View v) 
	    	{
	    		CruiseControlSystem.setThrustState();
	    		
	    		if( SensorSystem.getSafeOrNot() == true )            // 安全狀況 可加油門
	    		{
	    		
		    		if( CruiseControlSystem.getSpeed() >= 200 )
		    		{
		    			
	    				if( CruiseControlSystem.getTrustState() == true )
	    				{
	    					informationText.setTextColor(Color.BLUE);
	    	    			informationText.setText("*油門狀態：正常(速度達上限)");
	    				}
	    				else
	    				{
	    	    			informationText.setTextColor(Color.RED);
	    	    			informationText.setText("*油門狀態：異常(速度達上限)");
	    				}
		    		}
		    		else
		    		{
	
	    				if( CruiseControlSystem.getTrustState() == true )
	    				{
	    		    		CruiseControlSystem.setSpeed( t1.addSpeedConstant( CruiseControlSystem.getSpeed(), 10 ) );
	    	    			informationText.setTextColor(Color.BLUE);
	    					informationText.setText("*油門狀態：正常");
	    				}
	    				else
	    				{
	    	    			informationText.setTextColor(Color.RED);
	    					informationText.setText("*油門狀態：異常");
	    				}
	
		    			
		    		}
		    		
		    		speedText.setText("*速度:"+ CruiseControlSystem.getSpeed() +"km/hr");
	    		}
	    		else       // 不安全 不能加油門
	    		{

    				if( CruiseControlSystem.getTrustState() == true )
	    			{
						informationText.setText("*油門狀態：正常(車距過近)");
			    		speedText.setText("*速度:"+ CruiseControlSystem.getSpeed() +"km/hr");
    				}
    				else
    				{
						informationText.setText("*油門狀態：異常(車距過近)");
			    		speedText.setText("*速度:"+ CruiseControlSystem.getSpeed() +"km/hr");
    					
    				}
	    		}
	    	}
	    } );

	    
	    
		// 按鈕 ---> 減速(按一次減10)
	    Button speedBreak = (Button)findViewById(R.id.speedBreakButton); 
	    speedBreak.setOnClickListener(new Button.OnClickListener()
	    {
	    	@Override
	    	public void onClick(View v) 
	    	{
	    		if( CruiseControlSystem.getSpeed() <= 0 )
	    		{
	    			
	    				if( CruiseControlSystem.getTrustState() == true )
	    				{
	    	    			informationText.setTextColor(Color.BLUE);
	    					informationText.setText("*油門狀態：正常(速度達下限)");
	    				}
	    				else
	    				{
	    	    			informationText.setTextColor(Color.RED);
	    					informationText.setText("*油門狀態：異常(速度達下限)");
	    				}	
	    		}
	    		else
	    		{
		    		CruiseControlSystem.setSpeed( speedbreak.decreaseSpeedConstant(CruiseControlSystem.getSpeed(), 10 ) );
	    			
    				if( CruiseControlSystem.getTrustState() == true )
    				{
    	    			informationText.setTextColor(Color.BLUE);
    					informationText.setText("*油門狀態：正常");
    				}
    				else
    				{
    	    			informationText.setTextColor(Color.RED);
    					informationText.setText("*油門狀態：異常");
    				}
	    		}

	    		speedText.setText("*速度:"+ CruiseControlSystem.getSpeed() +"km/hr");
	    	}

	    } );
	    
	    
	    
	    
	    // ----------- 返回按鈕 ----------- //
		Button BACK = (Button)findViewById(R.id.backtoMain); 
		BACK.setOnClickListener(new Button.OnClickListener()
    	{
    		@Override
    		public void onClick(View v) 
    		{
				// TODO Auto-generated method stub 
				Intent intent = new Intent();
				intent.setClass(play.this, MainActivity.class);
				
				startActivity(intent); 
				play.this.finish();  
    		}
    	} );
	    // ----------- 返回按鈕 ----------- //
		
		
	    // ----------- 向左按鈕 ----------- //
		Button left = (Button)findViewById(R.id.leftButton); 
		left.setOnClickListener(new Button.OnClickListener()
    	{
    		@Override
    		public void onClick(View v) 
    		{
    			if( leadCarPosition_left_right >= 10 )
    				leadCarPosition_left_right = leadCarPosition_left_right - 10;
    		}
    	} );
	    // ----------- 向左按鈕 ----------- //
	   
	    // ----------- 向右按鈕 ----------- //
		Button right = (Button)findViewById(R.id.rightButton); 
		right.setOnClickListener(new Button.OnClickListener()
    	{
    		@Override
    		public void onClick(View v) 
    		{
    			if( leadCarPosition_left_right <= 400 )
    				leadCarPosition_left_right = leadCarPosition_left_right + 10;
    		}
    	} );
	    // ----------- 向右按鈕 ----------- //
		
	}
   
   public  class TimeThread extends Thread { 
       @Override 
       public  void run () { 
           do { 
               try { 
                   Thread.sleep( 1000 ); 
                   Message msg =  new Message(); 
                   msg.what = msgKey1; 
                   mHandler.sendMessage(msg); 
                   //Thread.sleep( 1000 ); 
               } 
               catch (InterruptedException e) { 
                   e.printStackTrace() ; 
               } 
           } while ( gameState == true );   // 當gameState 為 true --> do while 持續做下去 . gameState 為 false --> 結束thread
           
				Intent intent = new Intent();
				intent.setClass(play.this, MainActivity.class);
	    		
				startActivity(intent); 
				play.this.finish();  
       } 

   } 
   
   private Handler mHandler =  new Handler() { 
       @Override 
       public  void handleMessage (Message msg) { 
           super .handleMessage(msg); 
           switch (msg. what) { 
               case msgKey1: 
           			/*mString = "*分數: " +SensorSystem.getGrade( CruiseControlSystem.getSpeed() )  +"分";
          			//mString = "lead-bar距離"+  (leadCarPosition - barrierPosition) +"";
           			mText = (CharSequence)mString;
                   CharSequence sysTimeStr = mText; 
                   mTime.setText(sysTimeStr); */

                   safeOrNotText=(TextView)findViewById(R.id.distanceText);
                   
                   for( int i=0 ; i<50 ; i++ )
                   {
                	   //if( SensorSystem.safeOrNot( SensorSystem.getDistance(leadCarPosition, car2Position[i]) ) == true && ( leadCarPosition_left_right - car2LeftRight[i] <= 10 ) ) // 安全
                	   if( ( leadCarPosition - car2Position[i] <=230 && leadCarPosition - car2Position[i] >= 0 ) && ( (leadCarPosition_left_right - car2LeftRight[i] <= 100 && leadCarPosition_left_right - car2LeftRight[i] >= 0 ) || ( car2LeftRight[i] - leadCarPosition_left_right <=20 && car2LeftRight[i] - leadCarPosition_left_right >= 0 ) ) )
                	   {
                    	   safeOrNotText.setTextColor(Color.RED);
                       	   safeOrNotText.setText("*與前方車距：危險");
                       	   CruiseControlSystem.setSpeed( car2Speed[i] );

                       	   recordCarNumber = i;
                		   SensorSystem.setNotSafe();
                       	   /*while( true )
                       	   {
                       		   if( ( leadCarPosition - car2Position[i] >=230 && leadCarPosition - car2Position[i] >= 0 ) && ( (leadCarPosition_left_right - car2LeftRight[i] <= 40) && ( car2LeftRight[i] - leadCarPosition_left_right <=40 ) ) )
                       			   break;
                       	   }*/
                	   }
                	   else
                	   {
                		   if( SensorSystem.getSafeOrNot() == false )
                		   {
                			   if( ( leadCarPosition - car2Position[recordCarNumber] >=230 && leadCarPosition - car2Position[recordCarNumber] >= 0 ) || ( (leadCarPosition_left_right - car2LeftRight[recordCarNumber] >= 100 && leadCarPosition_left_right - car2LeftRight[recordCarNumber] >= 0) || ( car2LeftRight[recordCarNumber] - leadCarPosition_left_right >=20 && car2LeftRight[recordCarNumber] - leadCarPosition_left_right >=0 ) ) )
                			   {
                				   SensorSystem.setSafe();
    	                    	   safeOrNotText.setTextColor(Color.BLUE);
    	                       	   safeOrNotText.setText("*與前方車距：安全");
                			   }
                		   }
                		   else
                		   {
	                    	   safeOrNotText.setTextColor(Color.BLUE);
	                       	   safeOrNotText.setText("*與前方車距：安全");
	                		   SensorSystem.setSafe();
                		   }
                	   }
                   }
                   speedText=(TextView)findViewById(R.id.speedText);
                   speedText.setText("*速度:"+ CruiseControlSystem.getSpeed() +"km/hr");
                   break ; 
               
               default : 
                   break ; 
           } 
       } 
   };
   
   
   class Panel extends View
   {     	  
        public Panel(Context context) 
        {  
            super (context);
            bmp = BitmapFactory.decodeResource(getResources(), R.drawable.background_play);  
            carBmp = BitmapFactory.decodeResource(getResources(), R.drawable.car_play);  
            barrier = BitmapFactory.decodeResource(getResources(), R.drawable.barrier);  
            leadCarBmp = BitmapFactory.decodeResource(getResources(), R.drawable.leadcar);  
            
            	top = -bmp.getHeight();
            
            	
            
       }      
        
       public  void onDraw(Canvas canvas)
       {  
           canvas.drawColor(Color.BLACK);  
           
           // 背景移動
           if(top > bmp.getHeight()) 
           {
        	   top = -bmp.getHeight();
           } else 
           {
				// 若油門發生阻塞,無法進行加速
               //if( CruiseControlSystem.getTrustState() == true )
            	   top += CruiseControlSystem.getSpeed();
                         
           }
           
           
           // 畫背景
    	   canvas.drawBitmap(bmp, left, top- bmp.getHeight()*2 , null );  
    	   canvas.drawBitmap(bmp, left, top- bmp.getHeight() , null );  
    	   canvas.drawBitmap(bmp, left, top, null );  
    	   canvas.drawBitmap(bmp, left, top+ bmp.getHeight() , null );  
    	   canvas.drawBitmap(bmp, left, top+ bmp.getHeight()*2 , null );  

    	   // 畫前方車子 相對速度之計算
    	   for( int i=0 ; i<50 ; i++)
    		   car2Position[i] = car2Position[i] - ( car2Speed[i] - CruiseControlSystem.getSpeed() );
    	   
    	   
    	   for( int i=0 ; i<50 ; i++ )
    		   canvas.drawBitmap(carBmp, car2LeftRight[i], car2Position[i] , null );   
    	   
   		
    	   // 畫車子
    	   canvas.drawBitmap(leadCarBmp, leadCarPosition_left_right, leadCarPosition, null );  
    	   
    	   
    	   // 螢幕無限刷新
    	   invalidate();
       }  
       
       
   } 
	
}
