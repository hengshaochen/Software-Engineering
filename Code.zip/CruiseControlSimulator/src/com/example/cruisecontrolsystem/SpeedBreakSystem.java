package com.example.cruisecontrolsystem;

class SpeedBreakSystem extends CruiseControlSystem
{
	public void decreaseSpeed( int speed, int changePercentage )
	{
		int k =0;
		speed = speed - ( k*changePercentage );
		setSpeed( speed );
	}
	
	public int decreaseSpeedConstant( int speed, int speedConstant )
	{
		speed = speed - speedConstant;
		return speed;
	}
	
	public void calculateKconst()
	{
		
	}
}
