package com.example.cruisecontrolsystem;

class SensorSystem extends CruiseControlSystem
{
	private int distance;
	private int needChange;
	private int safeDistance;
	private boolean safeOrNot;
	private int nowGrade;
	
	// Constructor
	public SensorSystem()
	{
		this.distance = 0;
		this.needChange = 0;
		this.safeDistance = 220;
		this.safeOrNot = true;
		this.nowGrade = 0;
	}
	
	public int getDistance(int leadPos, int car2Pos )
	{
		distance = leadPos - car2Pos ;
		return distance;
	}
	
	public int getGrade( int nowSpeed )
	{
		nowGrade = nowGrade + nowSpeed ;
		return nowGrade;
	}
	
	public boolean safeOrNot( int aheadDistance )
	{
		if( aheadDistance <= safeDistance )
		{
			safeOrNot = false;			  // �q���r�p���A�󱱨�O���
			return false; 				  // ���w��
		}
		else
		{
			safeOrNot = true;			  // �N���b�w���d��,Do nothing
			return true;  				  // �w��
		}
	}
	
	public int calculateSafeDistance( int speed )
	{
		safeDistance = speed / 2;
		
		return safeDistance;
	}
	
	public int changeDistance( int speed, int distance )
	{
		needChange = speed - ( distance / 10 ) ;
		return needChange;   // �ѷ��e�t�׭p��X�ݭn��t���T��
	}
	
	public void setNotSafe()
	{
		safeOrNot = false;
	}
	
	public void setSafe()
	{
		safeOrNot = true;
	}
	
	public boolean getSafeOrNot()
	{
		return safeOrNot;
	}

}
