package com.example.cruisecontrolsystem;

import java.util.Random;

class CruiseControlSystem  
{
	private int speed;
	private boolean speedState;
	private boolean trustState; 
	
	// Constructor
	public CruiseControlSystem()
	{
		this.speed = 0;
		this.speedState = true;
		this.trustState = true;
	}
	
	public int getSpeed()
	{
		return speed;
	}
	
	public boolean getSpeedState()
	{
		return speedState;
	}
	
	public boolean getTrustState()
	{
		return trustState;
	}
	
	public void setSpeed( int newSpeed )
	{
		speed = newSpeed;
	}
	
	public void setSpeedState( boolean newState )
	{
		speedState = newState;
	}
	
	public void setThrustState( )
	{
		Random ran = new Random();
		int ranNumber = ran.nextInt(100);
		
		// �o���o�ͪ���
		if( ranNumber == 70 )
			trustState = false;
		

	}

}
